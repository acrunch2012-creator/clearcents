const money = n => new Intl.NumberFormat('en-GB',{style:'currency',currency:'GBP'}).format(n);
const num = id => Number(document.getElementById(id).value);
const result = (id, label, headline, detail, error=false) => {
  const el=document.getElementById(id);
  el.classList.toggle('error',error);
  el.innerHTML='';
  const l=document.createElement('span');l.className='result-label';l.textContent=label;
  const h=document.createElement('strong');h.textContent=headline;
  const p=document.createElement('p');p.textContent=detail;
  el.append(l,h,p);
};
function nonNegative(ids){return ids.every(id=>document.getElementById(id).value.trim()!=='' && Number.isFinite(num(id)) && num(id)>=0)}
document.getElementById('savings-form').addEventListener('submit',e=>{
 e.preventDefault();
 if(!nonNegative(['goal','saved','monthly'])||num('goal')<=0||num('monthly')<=0){result('savings-result','CHECK YOUR INPUTS','Enter valid amounts','Goal and monthly savings must be greater than £0.',true);return}
 const remaining=num('goal')-num('saved');
 if(remaining<=0){result('savings-result','GOAL STATUS','Goal reached','Your current savings meet or exceed your target.');return}
 const months=Math.ceil(remaining/num('monthly'));
 result('savings-result','YOUR ESTIMATE',months===1?'1 month':`${months} months`,`${money(remaining)} left to save at ${money(num('monthly'))} per month, excluding interest.`);
});
document.getElementById('budget-form').addEventListener('submit',e=>{
 e.preventDefault();
 const ids=['income','housing','food','other'];
 if(!nonNegative(ids)){result('budget-result','CHECK YOUR INPUTS','Enter valid amounts','Use zero or a positive number for each field.',true);return}
 const left=num('income')-num('housing')-num('food')-num('other');
 result('budget-result','LEFT AFTER LISTED COSTS',money(left),left<0?`Your listed costs exceed income by ${money(Math.abs(left))}. This is not a full financial assessment.`:'This excludes any costs you have not entered.');
});
document.getElementById('subscription-form').addEventListener('submit',e=>{
 e.preventDefault();
 if(!nonNegative(['sub-cost'])||num('sub-cost')<=0){result('subscription-result','CHECK YOUR INPUT','Enter a valid payment','Cost must be greater than £0.',true);return}
 const multiplier={weekly:52,monthly:12,quarterly:4,yearly:1}[document.getElementById('frequency').value];
 const annual=num('sub-cost')*multiplier;
 const name=document.getElementById('sub-name').value.trim();
 result('subscription-result','ESTIMATED YEARLY COST',money(annual),`${name?name+' costs':'This payment costs'} about ${money(annual/12)} per month on average.`);
});
document.getElementById('download-planner').addEventListener('click',()=>{
 const content=`CLEARCENTS — MONTHLY MONEY PLANNER\n\nMonth: ____________________\n\nINCOME\nSource                         Amount (£)\n_________________________      __________\n_________________________      __________\nTotal income                   __________\n\nREGULAR COSTS\nHousing and bills              __________\nFood and household             __________\nTransport                      __________\nSubscriptions                  __________\nOther                          __________\nTotal costs                    __________\n\nMONTHLY OVERVIEW\nTotal income                   __________\nMinus total costs              __________\nAmount left                    __________\n\nSAVINGS GOAL\nWhat am I saving for? ______________________________________\nTarget amount (£): __________  Amount saved (£): __________\n\nONE MONEY TASK FOR THIS MONTH\n___________________________________________________________\n\nThis planner is for general organisation, not financial advice.`;
 const blob=new Blob([content],{type:'text/plain;charset=utf-8'});
 const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='clearcents-monthly-planner.txt';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
});
document.getElementById('year').textContent=new Date().getFullYear();
